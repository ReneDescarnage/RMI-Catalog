package client.network;

public interface OutputHandler {

    public void handleMsg(String msg);
}
